#!/usr/bin/env python3
"""Paper-aligned source-domain UAV LLM speed-governance code.

Package purpose
---------------
This file is the cleaned main implementation for the *source domain e1 only*.
The target/e2 transfer code, paired Sim2Sim optimization branches, ROS/cuvSLAM
receiver utilities, OP-CBRS legacy code, and unused scene branches were removed.
The source-domain power-plant scene and route are imported from ``power_plant.py``.

Paper alignment
---------------
The code follows the manuscript equations for the source-domain policy-governor
module:

* mission text T -> (m, lambda), computed once per episode;
* 16-D mission vector with four interpretable blocks [E, G, S, O];
* one scalar PPO action mapped to bounded speed v_t;
* VSLAM risk score z_t using (a_n, a_i, a_s, a_xi, a_l);
* governed speed v_hat_t = v_t(1-alpha z_t)(1-beta lambda) with rate limit;
* gate g_t checking corridor, yaw, tracking loss, and VSLAM risk;
* paper reward r_t = wp*progress + wc*coverage - wd*d - wy*yaw - ws*smooth;
* state-only potential Phi(x_t) = c_delta*delta - c_d*d/bar_d - c_phi*phi/bar_phi;
* source-domain logging for success, coverage, RPE, ATE, energy, override, abort,
  drift return, and risk-score calibration.

Run examples
------------
Pure algorithm smoke test without Isaac rendering:
    python uav_llm.py --mode demo --no-isaac --demo-steps 200

Isaac Lab source-domain training:
    cd ~/IsaacLab
    ./isaaclab.sh -p /path/to/uav_llm/uav_llm.py --headless --mode train \
      --mission-encoder structured --total-timesteps 200000

Isaac GUI demo:
    cd ~/IsaacLab
    ./isaaclab.sh -p /path/to/uav_llm/uav_llm.py --mode demo --demo-steps 2000
"""

from __future__ import annotations

import argparse
import csv
import json
import math
import os
import time
from dataclasses import dataclass, asdict
from pathlib import Path
from typing import Any, Dict, List, Optional, Tuple

import numpy as np

try:
    import gymnasium as gym
    from gymnasium import spaces
except Exception:  # pragma: no cover - lightweight fallback for syntax/demo checks only
    class _FallbackEnv:
        metadata: Dict[str, Any] = {}

        def reset(self, *args, **kwargs):
            raise NotImplementedError

        def step(self, action):
            raise NotImplementedError

        def close(self):
            pass

    class _FallbackBox:
        def __init__(self, low, high, shape=None, dtype=np.float32):
            self.low = np.asarray(low, dtype=dtype) if shape is None else np.full(shape, low, dtype=dtype)
            self.high = np.asarray(high, dtype=dtype) if shape is None else np.full(shape, high, dtype=dtype)
            self.shape = self.low.shape if shape is None else tuple(shape)
            self.dtype = dtype

    class _FallbackSpaces:
        Box = _FallbackBox

    class _FallbackGym:
        Env = _FallbackEnv

    gym = _FallbackGym()
    spaces = _FallbackSpaces()

try:
    from power_plant import (
        BoxObstacle,
        CylinderObstacle,
        PowerPlantConfig,
        build_power_plant_source_scene,
        source_e1_box_obstacles,
        source_e1_cylinder_obstacles,
        source_e1_feature_points,
        source_e1_inspection_points,
        source_e1_route,
    )
except ImportError:  # pragma: no cover
    # Allows running from package parent when imported as uav_llm.uav_llm.
    from .power_plant import (  # type: ignore
        BoxObstacle,
        CylinderObstacle,
        PowerPlantConfig,
        build_power_plant_source_scene,
        source_e1_box_obstacles,
        source_e1_cylinder_obstacles,
        source_e1_feature_points,
        source_e1_inspection_points,
        source_e1_route,
    )

os.environ.setdefault("GYM_DISABLE_WARNINGS", "1")
os.environ.setdefault("PYTHONWARNINGS", "ignore::UserWarning:gym")


# ---------------------------------------------------------------------------
# Paper coefficients: source-domain method, not target transfer.
# ---------------------------------------------------------------------------


@dataclass
class PaperCoefficients:
    # Speed governor and risk score.
    speed_min: float = 0.30
    speed_max: float = 2.00
    alpha: float = 0.60
    beta: float = 0.40
    rate_limit: float = 0.20

    a_n: float = 0.45
    a_i: float = 0.55
    a_s: float = 0.40
    a_xi: float = 0.30
    a_l: float = 1.00

    z_limit: float = 0.70
    d_limit: float = 0.50
    phi_limit: float = 0.35
    z_abort: float = 0.90
    d_abort: float = 0.80
    phi_abort: float = 0.60
    fallback_speed: float = 0.0

    # Reward and shaping.
    w_p: float = 1.0
    w_c: float = 0.5
    w_d: float = 0.8
    w_y: float = 0.4
    w_s: float = 0.1
    c_delta: float = 1.0
    c_d: float = 0.5
    c_phi: float = 0.3
    gamma: float = 0.99

    # Drift/CVaR monitoring coefficients.
    k_d: float = 1.0
    k_phi: float = 0.5
    k_l: float = 2.0
    cvar_alpha: float = 0.90


# ---------------------------------------------------------------------------
# Mission encoder T -> (m, lambda)
# ---------------------------------------------------------------------------


class MissionEncoder:
    """Closed-vocabulary mission parser with optional Hugging Face LLaMA backend.

    The LLM is called only during initialization/reset mission encoding.  The
    control loop receives a numeric 16-D vector and never queries a language
    model at the control rate.
    """

    ENV_TOKENS = ["nominal", "low-texture", "low-light", "narrow", "wind", "repetitive", "stable"]
    GOAL_TOKENS = ["route", "coverage", "view-align", "route-stable", "drift-min", "safe-finish"]
    SAFETY_TOKENS = ["monitor", "feature-slow", "loss-hover", "yaw-strict", "deviation-slow", "hover-abort", "early-abort", "std-bounds"]
    OP_TOKENS = ["adaptive", "slow-smooth", "cautious", "rate-limit", "crawl", "fast", "smooth", "slow-hover", "minimal"]

    DEFAULT_RISK = {
        "monitor": 0.50,
        "feature-slow": 0.78,
        "loss-hover": 0.82,
        "yaw-strict": 0.85,
        "deviation-slow": 0.72,
        "hover-abort": 0.95,
        "early-abort": 0.92,
        "std-bounds": 0.30,
    }

    def __init__(
        self,
        backend: str = "structured",
        mission_dim: int = 16,
        model_name: str = "meta-llama/Meta-Llama-3-8B-Instruct",
        hf_token: str = "",
        local_files_only: bool = False,
        load_in_4bit: bool = False,
        device_map: str = "auto",
        max_new_tokens: int = 64,
    ) -> None:
        self.backend = str(backend or "structured").lower()
        self.mission_dim = int(max(16, mission_dim))
        self.model_name = str(model_name)
        self.hf_token = str(hf_token or os.environ.get("HF_TOKEN", "") or os.environ.get("HUGGINGFACE_HUB_TOKEN", ""))
        self.local_files_only = bool(local_files_only)
        self.load_in_4bit = bool(load_in_4bit)
        self.device_map = str(device_map or "auto")
        self.max_new_tokens = int(max(8, max_new_tokens))
        self.loaded = False
        self.tokenizer = None
        self.model = None
        self.torch = None
        self.last_raw_text = ""
        self.last_parsed: Dict[str, Any] = {}

        if self.backend == "llama_hf":
            self._try_load_llama()
        elif self.backend != "structured":
            raise ValueError("mission_encoder must be 'structured' or 'llama_hf'")

    @staticmethod
    def _token_code(token: str, vocab: List[str]) -> float:
        token = str(token or "").strip().lower()
        if token not in vocab:
            return 0.0
        return float(vocab.index(token)) / float(max(1, len(vocab) - 1))

    @staticmethod
    def _extract_field(text: str, key: str, default: str) -> str:
        import re

        m = re.search(rf"(?:^|\s){key}\s*:\s*([A-Za-z0-9_-]+)", str(text or ""), flags=re.IGNORECASE)
        return str(m.group(1)).lower() if m else default

    def _parse_structured(self, mission_text: str) -> Dict[str, Any]:
        env = self._extract_field(mission_text, "E", "nominal")
        goal = self._extract_field(mission_text, "G", "route")
        safety = self._extract_field(mission_text, "S", "monitor")
        op = self._extract_field(mission_text, "O", "adaptive")

        if env not in self.ENV_TOKENS:
            env = "nominal"
        if goal not in self.GOAL_TOKENS:
            goal = "route"
        if safety not in self.SAFETY_TOKENS:
            safety = "monitor"
        if op not in self.OP_TOKENS:
            op = "adaptive"

        risk = float(self.DEFAULT_RISK.get(safety, 0.50))
        if env in {"low-texture", "low-light", "narrow", "repetitive"}:
            risk = max(risk, 0.78)
        if op in {"crawl", "slow-hover", "minimal"}:
            risk = max(risk, 0.88)
        if op == "fast" and safety == "std-bounds":
            risk = min(risk, 0.35)
        return {"E": env, "G": goal, "S": safety, "O": op, "lambda": float(np.clip(risk, 0.0, 1.0))}

    def _try_load_llama(self) -> None:
        try:
            import torch
            from transformers import AutoModelForCausalLM, AutoTokenizer

            self.torch = torch
            tokenizer_kwargs: Dict[str, Any] = {"local_files_only": self.local_files_only}
            if self.hf_token:
                tokenizer_kwargs["token"] = self.hf_token
            self.tokenizer = AutoTokenizer.from_pretrained(self.model_name, **tokenizer_kwargs)

            model_kwargs: Dict[str, Any] = {"device_map": self.device_map, "local_files_only": self.local_files_only}
            if self.hf_token:
                model_kwargs["token"] = self.hf_token
            if self.load_in_4bit:
                try:
                    from transformers import BitsAndBytesConfig

                    model_kwargs["quantization_config"] = BitsAndBytesConfig(
                        load_in_4bit=True,
                        bnb_4bit_compute_dtype=torch.float16,
                        bnb_4bit_use_double_quant=True,
                        bnb_4bit_quant_type="nf4",
                    )
                except Exception:
                    model_kwargs["torch_dtype"] = "auto"
            else:
                model_kwargs["torch_dtype"] = "auto"

            self.model = AutoModelForCausalLM.from_pretrained(self.model_name, **model_kwargs)
            self.loaded = True
            print(f"[MISSION] Loaded Hugging Face LLaMA mission encoder: {self.model_name}")
        except Exception as exc:
            self.loaded = False
            self.tokenizer = None
            self.model = None
            print(f"[MISSION] LLaMA unavailable, using structured parser. Reason: {exc}")

    @staticmethod
    def _first_json(text: str) -> Optional[Dict[str, Any]]:
        s = str(text or "")
        start, end = s.find("{"), s.rfind("}")
        if start < 0 or end <= start:
            return None
        try:
            return json.loads(s[start : end + 1])
        except Exception:
            return None

    def _parse_with_llama(self, mission_text: str) -> Dict[str, Any]:
        base = self._parse_structured(mission_text)
        if not self.loaded or self.model is None or self.tokenizer is None:
            return base

        prompt = (
            "Convert the UAV inspection mission into exactly one JSON object.\n"
            f"Allowed E: {', '.join(self.ENV_TOKENS)}.\n"
            f"Allowed G: {', '.join(self.GOAL_TOKENS)}.\n"
            f"Allowed S: {', '.join(self.SAFETY_TOKENS)}.\n"
            f"Allowed O: {', '.join(self.OP_TOKENS)}.\n"
            "Return only JSON, e.g. {\"E\":\"low-texture\",\"G\":\"coverage\",\"S\":\"feature-slow\",\"O\":\"slow-smooth\",\"lambda\":0.78}.\n"
            f"Mission: {mission_text}\nJSON:"
        )
        try:
            inputs = self.tokenizer(prompt, return_tensors="pt")
            try:
                dev = next(self.model.parameters()).device
                inputs = {k: v.to(dev) for k, v in inputs.items()}
            except Exception:
                pass
            prompt_len = int(inputs["input_ids"].shape[1])
            pad_id = self.tokenizer.pad_token_id or self.tokenizer.eos_token_id or 0
            eos_id = self.tokenizer.eos_token_id
            with self.torch.no_grad():
                out = self.model.generate(
                    **inputs,
                    max_new_tokens=self.max_new_tokens,
                    do_sample=False,
                    num_beams=1,
                    pad_token_id=pad_id,
                    eos_token_id=eos_id,
                    use_cache=True,
                )
            text = self.tokenizer.decode(out[0][prompt_len:], skip_special_tokens=True).strip()
            self.last_raw_text = text
            parsed = self._first_json(text) or self._first_json(self.tokenizer.decode(out[0], skip_special_tokens=True))
            if not parsed:
                return base
            checked = {
                "E": str(parsed.get("E", base["E"])).strip().lower(),
                "G": str(parsed.get("G", base["G"])).strip().lower(),
                "S": str(parsed.get("S", base["S"])).strip().lower(),
                "O": str(parsed.get("O", base["O"])).strip().lower(),
                "lambda": float(parsed.get("lambda", base["lambda"])),
            }
            if checked["E"] not in self.ENV_TOKENS:
                checked["E"] = base["E"]
            if checked["G"] not in self.GOAL_TOKENS:
                checked["G"] = base["G"]
            if checked["S"] not in self.SAFETY_TOKENS:
                checked["S"] = base["S"]
            if checked["O"] not in self.OP_TOKENS:
                checked["O"] = base["O"]
            checked["lambda"] = float(np.clip(checked["lambda"], 0.0, 1.0))
            return checked
        except Exception as exc:
            print(f"[MISSION] LLaMA generation failed, using structured parser. Reason: {exc}")
            return base

    def _project_to_vector(self, parsed: Dict[str, Any]) -> np.ndarray:
        e = self._token_code(parsed.get("E", "nominal"), self.ENV_TOKENS)
        g = self._token_code(parsed.get("G", "route"), self.GOAL_TOKENS)
        s = self._token_code(parsed.get("S", "monitor"), self.SAFETY_TOKENS)
        o = self._token_code(parsed.get("O", "adaptive"), self.OP_TOKENS)
        lam = float(np.clip(parsed.get("lambda", 0.50), 0.0, 1.0))
        blocks = np.asarray(
            [
                [e, 1.0 - e, lam, 0.25 + 0.75 * e],
                [g, 1.0 - g, 0.5 * lam + 0.5 * g, 0.25 + 0.75 * g],
                [s, 1.0 - s, lam, 0.25 + 0.75 * s],
                [o, 1.0 - o, 1.0 - lam, 0.25 + 0.75 * o],
            ],
            dtype=np.float32,
        ).reshape(-1)
        if self.mission_dim == 16:
            return blocks
        out = np.zeros((self.mission_dim,), dtype=np.float32)
        out[: min(self.mission_dim, 16)] = blocks[: min(self.mission_dim, 16)]
        return out

    def encode(self, mission_text: str) -> Tuple[np.ndarray, float, Dict[str, Any]]:
        parsed = self._parse_with_llama(mission_text) if self.backend == "llama_hf" else self._parse_structured(mission_text)
        self.last_parsed = dict(parsed)
        m = self._project_to_vector(parsed)
        lam = float(np.clip(parsed.get("lambda", 0.50), 0.0, 1.0))
        return m.astype(np.float32), lam, dict(parsed)


# ---------------------------------------------------------------------------
# Source-domain Gym environment
# ---------------------------------------------------------------------------


class SourceE1UAVEnv(gym.Env):
    """Source-domain e1 UAV inspection environment.

    This environment does not contain e2/target transfer logic.  It is intended
    for source-domain policy training and evaluation against the paper's
    VSLAM-aware speed-governance formulation.
    """

    metadata = {"render_modes": ["human"], "render_fps": 20}

    def __init__(
        self,
        render_stage: bool = False,
        stage: Any = None,
        seed: int = 7,
        output_root: str = "~/uav_results_e1",
        max_episode_steps: int = 6000,
        mission_text: str = "E:low-texture G:coverage S:feature-slow O:slow-smooth",
        mission_encoder: str = "structured",
        mission_dim: int = 16,
        hf_llama_model: str = "meta-llama/Meta-Llama-3-8B-Instruct",
        hf_token: str = "",
        hf_local_files_only: bool = False,
        hf_load_in_4bit: bool = False,
        hf_device_map: str = "auto",
        route_repeat_count: int = 1,
        world_size: float = 64.0,
        inspection_altitude: float = 12.0,
        inspection_reach_radius: float = 1.25,
        num_rays: int = 36,
        domain_randomization: bool = True,
        route_randomization: bool = False,
        collision_termination: bool = True,
        coeffs: Optional[PaperCoefficients] = None,
    ) -> None:
        super().__init__()
        self.coeffs = coeffs or PaperCoefficients()
        self.dt = 0.05  # 20 Hz, consistent with the paper baseline description.
        self.rng = np.random.default_rng(seed)
        self.seed_value = int(seed)
        self.max_episode_steps = int(max_episode_steps)
        self.inspection_reach_radius = float(max(0.1, inspection_reach_radius))
        self.num_rays = int(max(8, num_rays))
        self.domain_randomization = bool(domain_randomization)
        self.route_randomization = bool(route_randomization)
        self.collision_termination = bool(collision_termination)
        self.render_stage = bool(render_stage)
        self.stage = stage
        self.output_root = Path(output_root).expanduser()
        self.metrics_dir = self.output_root / "metrics"
        self.trajectory_dir = self.output_root / "trajectories"
        self.metrics_dir.mkdir(parents=True, exist_ok=True)
        self.trajectory_dir.mkdir(parents=True, exist_ok=True)
        self.step_csv = self.metrics_dir / "source_e1_step_metrics.csv"
        self.episode_csv = self.metrics_dir / "source_e1_episode_metrics.csv"
        self.summary_json = self.metrics_dir / "source_e1_summary.json"
        self.run_id = time.strftime("%Y%m%d_%H%M%S")

        self.scene_config = PowerPlantConfig(
            world_size=float(world_size),
            inspection_altitude=float(inspection_altitude),
            route_repeat_count=int(max(1, route_repeat_count)),
        )
        self.inspection_points = source_e1_inspection_points(self.scene_config)
        self.route = source_e1_route(self.scene_config)
        self.feature_points = source_e1_feature_points(self.scene_config, seed=2026)
        self.box_obstacles = source_e1_box_obstacles()
        self.cylinder_obstacles = source_e1_cylinder_obstacles()
        self.world_size = float(world_size)

        self.drone_path = "/World/Drone/body"
        if self.render_stage and self.stage is not None:
            try:
                data = build_power_plant_source_scene(self.stage, self.scene_config)
                self.drone_path = str(data.get("drone_path", self.drone_path))
                print("[SCENE] Built source-domain e1 power plant from power_plant.py")
            except Exception as exc:
                print(f"[SCENE] Could not build USD scene. Running algorithmic env only. Reason: {exc}")
                self.render_stage = False

        self.mission_encoder = MissionEncoder(
            backend=mission_encoder,
            mission_dim=mission_dim,
            model_name=hf_llama_model,
            hf_token=hf_token,
            local_files_only=hf_local_files_only,
            load_in_4bit=hf_load_in_4bit,
            device_map=hf_device_map,
        )
        self.mission_text = str(mission_text)
        self.mission_vector, self.mission_lambda, self.mission_meta = self.mission_encoder.encode(self.mission_text)
        print(f"[MISSION] text='{self.mission_text}' parsed={self.mission_meta} lambda={self.mission_lambda:.3f}")

        # One scalar policy action, mapped to bounded speed before the governor.
        self.action_space = spaces.Box(low=np.array([-1.0], dtype=np.float32), high=np.array([1.0], dtype=np.float32), dtype=np.float32)

        # Observation x_t = [h, q, b, c, e, target_rel, prev_action, ray_features, m, lambda]
        # h: n,i,sigma,xi,ell (5)
        # q: slam_pos3, yaw_sin, yaw_cos, measured_speed, yaw_rate (7)
        # b: accel3, gyro3 (6)
        # c: texture, illumination, wind (3)
        # e: lateral error, yaw error, route progress (3)
        # target_rel: 3
        # prev_action: 1
        # ray features: num_rays
        # mission: mission_dim + lambda
        self.obs_dim = 5 + 7 + 6 + 3 + 3 + 3 + 1 + self.num_rays + int(mission_dim) + 1
        self.observation_space = spaces.Box(low=-np.inf, high=np.inf, shape=(self.obs_dim,), dtype=np.float32)

        self.episode_id = 0
        self.summary: Dict[str, Any] = {"episodes": 0, "successes": 0, "aborts": 0, "drift_returns": []}
        self._ensure_csv_headers()
        self.reset(seed=seed)

    # ------------------------------------------------------------------
    # Helpers
    # ------------------------------------------------------------------

    @staticmethod
    def _wrap_angle(a: float) -> float:
        return float((a + math.pi) % (2.0 * math.pi) - math.pi)

    @staticmethod
    def _safe_norm(v: np.ndarray, eps: float = 1e-8) -> float:
        return float(np.linalg.norm(v) + eps)

    def _ensure_csv_headers(self) -> None:
        if not self.step_csv.exists():
            with self.step_csv.open("w", newline="") as f:
                writer = csv.DictWriter(f, fieldnames=self._step_metric_fields())
                writer.writeheader()
        if not self.episode_csv.exists():
            with self.episode_csv.open("w", newline="") as f:
                writer = csv.DictWriter(f, fieldnames=self._episode_metric_fields())
                writer.writeheader()

    @staticmethod
    def _step_metric_fields() -> List[str]:
        return [
            "run_id",
            "episode",
            "step",
            "target_idx",
            "x",
            "y",
            "z",
            "slam_x",
            "slam_y",
            "slam_z",
            "policy_speed_mps",
            "governed_speed_mps",
            "command_speed_mps",
            "vslam_risk_z",
            "feature_norm_n",
            "inlier_ratio_i",
            "sigma_pos",
            "xi_yaw",
            "tracking_loss_l",
            "route_lateral_error_m",
            "route_yaw_error_rad",
            "gate",
            "override",
            "abort",
            "reward",
            "coverage",
            "route_progress",
            "energy_wh_step",
            "rpe_pos_m",
            "rpe_yaw_rad",
        ]

    @staticmethod
    def _episode_metric_fields() -> List[str]:
        return [
            "run_id",
            "episode",
            "success",
            "aborted",
            "steps",
            "waypoints_reached",
            "P_s",
            "coverage_C",
            "E_p_rpe_m",
            "E_psi_rpe_rad",
            "E_a_ate_m",
            "energy_Wh",
            "override_rate_O",
            "abort_rate_A",
            "drift_return_D",
            "mean_vslam_risk_z",
            "max_vslam_risk_z",
            "mean_speed_mps",
            "reward_sum",
            "mission_text",
            "mission_lambda",
        ]

    def _sync_drone_prim(self) -> None:
        if not self.render_stage or self.stage is None:
            return
        try:
            from pxr import Gf, UsdGeom  # type: ignore

            prim = self.stage.GetPrimAtPath(self.drone_path)
            if not prim or not prim.IsValid():
                return
            xform = UsdGeom.Xformable(prim)
            # Clear ops only once is expensive; instead set existing or add simple ops.
            ops = xform.GetOrderedXformOps()
            if not ops:
                xform.AddTranslateOp().Set(Gf.Vec3d(float(self.true_pos[0]), float(self.true_pos[1]), float(self.true_pos[2])))
                xform.AddRotateXYZOp().Set(Gf.Vec3f(0.0, 0.0, float(math.degrees(self.true_yaw))))
            else:
                for op in ops:
                    if "translate" in op.GetOpName():
                        op.Set(Gf.Vec3d(float(self.true_pos[0]), float(self.true_pos[1]), float(self.true_pos[2])))
                    elif "rotate" in op.GetOpName():
                        op.Set(Gf.Vec3f(0.0, 0.0, float(math.degrees(self.true_yaw))))
        except Exception:
            pass

    def _distance_to_box_surface(self, point: np.ndarray, box: BoxObstacle) -> float:
        c = np.asarray(box.center, dtype=np.float32)
        half = 0.5 * np.asarray(box.size, dtype=np.float32)
        q = np.maximum(np.abs(point - c) - half, 0.0)
        return float(np.linalg.norm(q))

    def _inside_box(self, point: np.ndarray, box: BoxObstacle, margin: float = 0.0) -> bool:
        c = np.asarray(box.center, dtype=np.float32)
        half = 0.5 * np.asarray(box.size, dtype=np.float32) + float(margin)
        return bool(np.all(np.abs(point - c) <= half))

    def _inside_cylinder(self, point: np.ndarray, cyl: CylinderObstacle, margin: float = 0.0) -> bool:
        cx, cy, cz = cyl.center
        r = float(cyl.radius + margin)
        h = float(cyl.height) * 0.5 + margin
        xy = float(np.linalg.norm(point[:2] - np.array([cx, cy], dtype=np.float32)))
        return bool(xy <= r and abs(float(point[2]) - cz) <= h)

    def _collision_or_avoidance(self, point: np.ndarray, margin: float = 0.0) -> Tuple[bool, str]:
        for box in self.box_obstacles:
            if self._inside_box(point, box, margin):
                return True, box.name
        for cyl in self.cylinder_obstacles:
            if self._inside_cylinder(point, cyl, margin):
                return True, cyl.name
        return False, ""

    def _avoidance_vector(self, point: np.ndarray) -> np.ndarray:
        rep = np.zeros(3, dtype=np.float32)
        # Push away from boxes.
        for box in self.box_obstacles:
            c = np.asarray(box.center, dtype=np.float32)
            diff = point - c
            d_xy = float(np.linalg.norm(diff[:2]) + 1e-6)
            influence = 4.0
            surface = self._distance_to_box_surface(point, box)
            if surface < influence:
                rep[:2] += (diff[:2] / d_xy) * float((influence - surface) / influence) * 0.7
        # Push away from cylinders.
        for cyl in self.cylinder_obstacles:
            c = np.asarray(cyl.center, dtype=np.float32)
            diff_xy = point[:2] - c[:2]
            d_xy = float(np.linalg.norm(diff_xy) + 1e-6)
            influence = cyl.radius + 3.0
            if d_xy < influence:
                rep[:2] += (diff_xy / d_xy) * float((influence - d_xy) / influence) * 1.2
        return rep

    def _route_segment(self) -> Tuple[np.ndarray, np.ndarray]:
        idx = int(np.clip(self.target_idx, 0, len(self.route) - 1))
        prev_idx = max(0, idx - 1)
        a = self.route[prev_idx].astype(np.float32)
        b = self.route[idx].astype(np.float32)
        if idx == 0:
            # Synthetic incoming segment to make lateral error well defined at start.
            b = self.route[0].astype(np.float32)
            a = b + np.array([-3.0, 0.0, 0.0], dtype=np.float32)
        return a, b

    def _route_errors(self) -> Tuple[float, float, float]:
        a, b = self._route_segment()
        ab = b - a
        ap = self.true_pos - a
        denom = float(np.dot(ab, ab) + 1e-8)
        tau = float(np.clip(np.dot(ap, ab) / denom, 0.0, 1.0))
        closest = a + tau * ab
        lateral = float(np.linalg.norm(self.true_pos[:2] - closest[:2]))
        desired_yaw = math.atan2(float(ab[1]), float(ab[0]))
        yaw_error = abs(self._wrap_angle(self.true_yaw - desired_yaw))
        route_progress = (float(self.target_idx) + tau) / float(max(1, len(self.route) - 1))
        return lateral, yaw_error, float(np.clip(route_progress, 0.0, 1.0))

    def _coverage(self) -> float:
        dists = np.linalg.norm(self.inspection_points - self.true_pos.reshape(1, 3), axis=1)
        self.coverage_visited |= dists <= self.inspection_reach_radius
        return float(np.mean(self.coverage_visited.astype(np.float32)))

    def _ray_features(self) -> np.ndarray:
        # Lightweight 2-D range features to static obstacles, normalized to [0,1].
        rays = np.ones((self.num_rays,), dtype=np.float32)
        origin = self.true_pos.copy()
        max_range = 12.0
        for k in range(self.num_rays):
            theta = self.true_yaw + 2.0 * math.pi * k / self.num_rays
            direction = np.array([math.cos(theta), math.sin(theta), 0.0], dtype=np.float32)
            best = max_range
            for r in np.linspace(0.5, max_range, 24):
                p = origin + direction * float(r)
                hit, _name = self._collision_or_avoidance(p, margin=0.10)
                if hit:
                    best = float(r)
                    break
            rays[k] = best / max_range
        return rays

    # ------------------------------------------------------------------
    # VSLAM proxy, governor, reward
    # ------------------------------------------------------------------

    def _update_conditions(self) -> None:
        if self.domain_randomization:
            self.texture_level = float(np.clip(self.texture_level + self.rng.normal(0.0, 0.004), 0.15, 1.0))
            self.illumination_level = float(np.clip(self.illumination_level + self.rng.normal(0.0, 0.003), 0.20, 1.0))
            self.wind_mps = float(np.clip(self.wind_mps + self.rng.normal(0.0, 0.015), 0.0, 2.5))

    def _update_slam_proxy(self, command_speed: float) -> Dict[str, float]:
        self._update_conditions()
        wind_norm = float(np.clip(self.wind_mps / 2.5, 0.0, 1.0))
        speed_norm = float(np.clip(command_speed / max(self.coeffs.speed_max, 1e-6), 0.0, 1.0))

        # Feature count and inlier ratio are directly observable VSLAM-health proxies.
        feature_norm = float(np.clip(0.15 + 0.70 * self.texture_level + 0.15 * self.illumination_level - 0.12 * wind_norm, 0.0, 1.0))
        inlier_ratio = float(np.clip(0.10 + 0.60 * self.texture_level + 0.25 * self.illumination_level - 0.10 * speed_norm, 0.0, 1.0))

        # Position/yaw uncertainty increase when visual quality is weak and speed/wind are high.
        sigma_pos = float(np.clip(0.10 + 0.45 * (1.0 - feature_norm) + 0.25 * speed_norm + 0.20 * wind_norm, 0.0, 1.0))
        xi_yaw = float(np.clip(0.08 + 0.42 * (1.0 - inlier_ratio) + 0.25 * wind_norm, 0.0, 1.0))
        loss_prob = float(np.clip(0.002 + 0.04 * (1.0 - feature_norm) + 0.02 * speed_norm + 0.02 * wind_norm, 0.0, 0.25))
        tracking_loss = 1.0 if self.rng.random() < loss_prob else 0.0

        drift_scale = 0.01 + 0.035 * sigma_pos + 0.020 * speed_norm + 0.015 * wind_norm
        drift_step = self.rng.normal(0.0, drift_scale, size=3).astype(np.float32)
        drift_step[2] *= 0.25
        if tracking_loss > 0.5:
            drift_step += self.rng.normal(0.0, 0.12, size=3).astype(np.float32)
            drift_step[2] *= 0.2
        self.slam_drift = 0.995 * self.slam_drift + drift_step
        self.slam_pos = self.true_pos + self.slam_drift
        self.slam_vel = (self.slam_pos - self.prev_slam_pos_for_vel) / self.dt
        self.prev_slam_pos_for_vel = self.slam_pos.copy()
        yaw_noise = float(self.rng.normal(0.0, 0.02 + 0.10 * xi_yaw))
        self.slam_yaw = self._wrap_angle(self.true_yaw + yaw_noise)
        self.slam_quality = float(np.clip(1.0 - 0.65 * sigma_pos - 0.35 * xi_yaw - tracking_loss, 0.0, 1.0))

        z = self._vslam_risk_score(feature_norm, inlier_ratio, sigma_pos, xi_yaw, tracking_loss)
        return {
            "n_t": feature_norm,
            "i_t": inlier_ratio,
            "sigma_t": sigma_pos,
            "xi_t": xi_yaw,
            "ell_t": tracking_loss,
            "z_t": z,
            "quality": self.slam_quality,
        }

    def _vslam_risk_score(self, n_t: float, i_t: float, sigma_t: float, xi_t: float, ell_t: float) -> float:
        c = self.coeffs
        health = np.clip(c.a_n * n_t + c.a_i * i_t - c.a_s * sigma_t - c.a_xi * xi_t - c.a_l * ell_t, 0.0, 1.0)
        return float(np.clip(1.0 - health, 0.0, 1.0))

    def _action_to_policy_speed(self, action: np.ndarray) -> float:
        a = float(np.clip(np.asarray(action, dtype=np.float32).reshape(-1)[0], -1.0, 1.0))
        return float(self.coeffs.speed_min + 0.5 * (a + 1.0) * (self.coeffs.speed_max - self.coeffs.speed_min))

    def _govern_speed(self, policy_speed: float, z_t: float, ell_t: float, d_t: float, phi_t: float) -> Tuple[float, int, int, int, str]:
        c = self.coeffs
        v_tilde = policy_speed * (1.0 - c.alpha * z_t) * (1.0 - c.beta * self.mission_lambda)
        v_tilde = float(np.clip(v_tilde, c.speed_min, c.speed_max))
        governed = float(np.clip(v_tilde, self.prev_governed_speed - c.rate_limit, self.prev_governed_speed + c.rate_limit))
        governed = float(np.clip(governed, c.speed_min, c.speed_max))

        gate = int(d_t <= c.d_limit and phi_t <= c.phi_limit and ell_t < 0.5 and z_t <= c.z_limit)
        abort = int(ell_t > 0.5 or d_t > c.d_abort or phi_t > c.phi_abort or z_t > c.z_abort)
        if abort:
            return 0.0, gate, 1, int(abs(policy_speed) > 1e-6), "abort"
        if not gate:
            return float(c.fallback_speed), 0, 0, int(abs(policy_speed - c.fallback_speed) > 1e-6), "fallback"
        override = int(abs(governed - policy_speed) > 1e-4)
        return governed, 1, 0, override, "accept"

    def _state_potential(self, route_progress: float, d_t: float, phi_t: float) -> float:
        c = self.coeffs
        return float(c.c_delta * route_progress - c.c_d * (d_t / max(c.d_limit, 1e-6)) - c.c_phi * (phi_t / max(c.phi_limit, 1e-6)))

    def _drift_cost(self, d_t: float, phi_t: float, ell_t: float) -> float:
        c = self.coeffs
        return float(
            c.k_d * np.clip(d_t / max(c.d_limit, 1e-6), 0.0, 1.0)
            + c.k_phi * np.clip(phi_t / max(c.phi_limit, 1e-6), 0.0, 1.0)
            + c.k_l * ell_t
        )

    # ------------------------------------------------------------------
    # Gym API
    # ------------------------------------------------------------------

    def reset(self, *, seed: Optional[int] = None, options: Optional[Dict[str, Any]] = None):
        if seed is not None:
            self.rng = np.random.default_rng(seed)

        self.step_count = 0
        self.episode_reward = 0.0
        self.target_idx = 0
        self.true_pos = self.route[0].astype(np.float32).copy()
        self.true_pos[0] -= 2.5
        self.true_yaw = 0.0
        self.true_vel = np.zeros(3, dtype=np.float32)
        self.yaw_rate = 0.0
        self.prev_action = np.zeros(1, dtype=np.float32)
        self.prev_policy_speed = self.coeffs.speed_min
        self.prev_governed_speed = self.coeffs.speed_min
        self.prev_route_progress = 0.0
        self.prev_coverage = 0.0
        self.coverage_visited = np.zeros((len(self.inspection_points),), dtype=bool)

        if self.domain_randomization:
            self.texture_level = float(self.rng.uniform(0.40, 0.95))
            self.illumination_level = float(self.rng.uniform(0.45, 1.00))
            self.wind_mps = float(self.rng.uniform(0.0, 1.6))
        else:
            self.texture_level = 0.72
            self.illumination_level = 0.80
            self.wind_mps = 0.40

        self.slam_drift = np.zeros(3, dtype=np.float32)
        self.slam_pos = self.true_pos.copy()
        self.slam_vel = np.zeros(3, dtype=np.float32)
        self.slam_yaw = self.true_yaw
        self.slam_quality = 1.0
        self.prev_slam_pos_for_vel = self.slam_pos.copy()

        self.prev_true_pos = self.true_pos.copy()
        self.prev_slam_pos = self.slam_pos.copy()
        self.prev_true_yaw = self.true_yaw
        self.prev_slam_yaw = self.slam_yaw
        self.prev_potential = self._state_potential(0.0, 0.0, 0.0)

        self.step_rows: List[Dict[str, Any]] = []
        self.rpe_pos_values: List[float] = []
        self.rpe_yaw_values: List[float] = []
        self.ate_values: List[float] = []
        self.energy_values: List[float] = []
        self.risk_values: List[float] = []
        self.speed_values: List[float] = []
        self.override_count = 0
        self.abort_count = 0
        self.accept_count = 0
        self.drift_return = 0.0

        self._sync_drone_prim()
        return self._get_obs(), {"mission": self.mission_meta, "source_domain": "e1"}

    def step(self, action: np.ndarray):
        self.step_count += 1
        policy_speed = self._action_to_policy_speed(action)

        # Route state before command.  Gate can reject command; yaw still rotates.
        d_t, phi_t, route_progress_before = self._route_errors()
        nav = self._update_slam_proxy(command_speed=self.prev_governed_speed)
        z_t, ell_t = float(nav["z_t"]), float(nav["ell_t"])
        command_speed, gate, abort, override, reason = self._govern_speed(policy_speed, z_t, ell_t, d_t, phi_t)

        # Low-level waypoint following.  Policy controls only forward speed.
        target = self.route[min(self.target_idx, len(self.route) - 1)].astype(np.float32)
        to_target = target - self.true_pos
        dist_to_target = self._safe_norm(to_target)
        direction = to_target / dist_to_target
        avoidance = self._avoidance_vector(self.true_pos)
        move_dir = direction + 0.35 * avoidance
        move_dir[2] *= 0.35
        move_norm = self._safe_norm(move_dir)
        move_dir = move_dir / move_norm

        desired_yaw = math.atan2(float(direction[1]), float(direction[0]))
        yaw_err_signed = self._wrap_angle(desired_yaw - self.true_yaw)
        self.yaw_rate = float(np.clip(2.0 * yaw_err_signed, -1.0, 1.0))
        self.true_yaw = self._wrap_angle(self.true_yaw + self.yaw_rate * self.dt)

        wind_push = np.array([0.015 * self.wind_mps, -0.008 * self.wind_mps, 0.0], dtype=np.float32)
        prev_true = self.true_pos.copy()
        candidate = self.true_pos + move_dir * command_speed * self.dt + wind_push * self.dt
        candidate[2] = float(np.clip(candidate[2], self.scene_config.inspection_altitude - 1.0, self.scene_config.inspection_altitude + 1.0))
        hit, hit_name = self._collision_or_avoidance(candidate, margin=0.15)
        if hit:
            # Do not fly through plant structures.  Either terminate or freeze and penalize.
            if self.collision_termination:
                abort = 1
                reason = f"collision:{hit_name}"
                command_speed = 0.0
            candidate = self.true_pos.copy()

        self.true_pos = candidate.astype(np.float32)
        self.true_vel = (self.true_pos - prev_true) / self.dt

        reached = dist_to_target <= self.inspection_reach_radius
        if reached and self.target_idx < len(self.route) - 1:
            self.target_idx += 1

        d_next, phi_next, route_progress = self._route_errors()
        coverage = self._coverage()
        delta_progress = max(0.0, route_progress - self.prev_route_progress)
        delta_coverage = max(0.0, coverage - self.prev_coverage)

        c = self.coeffs
        smooth = (command_speed - self.prev_governed_speed) ** 2
        base_reward = (
            c.w_p * delta_progress
            + c.w_c * delta_coverage
            - c.w_d * (d_next / max(c.d_limit, 1e-6))
            - c.w_y * (phi_next / max(c.phi_limit, 1e-6))
            - c.w_s * smooth
        )
        phi_state = self._state_potential(route_progress, d_next, phi_next)
        shaped_reward = base_reward + c.gamma * phi_state - self.prev_potential
        reward = float(shaped_reward)

        drift_cost = self._drift_cost(d_next, phi_next, ell_t)
        self.drift_return += (c.gamma ** max(0, self.step_count - 1)) * drift_cost

        # Metrics: RPE uses consecutive estimated vs ground-truth pose increments.
        slam_delta = self.slam_pos - self.prev_slam_pos
        true_delta = self.true_pos - self.prev_true_pos
        rpe_pos = float(np.linalg.norm(slam_delta - true_delta))
        rpe_yaw = abs(self._wrap_angle((self.slam_yaw - self.prev_slam_yaw) - (self.true_yaw - self.prev_true_yaw)))
        ate = float(np.linalg.norm(self.slam_pos - self.true_pos))
        energy = float((180.0 + 32.0 * command_speed * command_speed) * self.dt / 3600.0)

        self.rpe_pos_values.append(rpe_pos)
        self.rpe_yaw_values.append(rpe_yaw)
        self.ate_values.append(ate)
        self.energy_values.append(energy)
        self.risk_values.append(z_t)
        self.speed_values.append(command_speed)
        self.override_count += int(override)
        self.abort_count += int(abort)
        self.accept_count += int(gate)
        self.episode_reward += reward

        success = bool(self.target_idx >= len(self.route) - 1 and reached)
        timeout = bool(self.step_count >= self.max_episode_steps)
        terminated = bool(success or abort)
        truncated = bool(timeout and not terminated)

        row = {
            "run_id": self.run_id,
            "episode": self.episode_id,
            "step": self.step_count,
            "target_idx": self.target_idx,
            "x": float(self.true_pos[0]),
            "y": float(self.true_pos[1]),
            "z": float(self.true_pos[2]),
            "slam_x": float(self.slam_pos[0]),
            "slam_y": float(self.slam_pos[1]),
            "slam_z": float(self.slam_pos[2]),
            "policy_speed_mps": policy_speed,
            "governed_speed_mps": command_speed,
            "command_speed_mps": command_speed,
            "vslam_risk_z": z_t,
            "feature_norm_n": float(nav["n_t"]),
            "inlier_ratio_i": float(nav["i_t"]),
            "sigma_pos": float(nav["sigma_t"]),
            "xi_yaw": float(nav["xi_t"]),
            "tracking_loss_l": float(nav["ell_t"]),
            "route_lateral_error_m": d_next,
            "route_yaw_error_rad": phi_next,
            "gate": gate,
            "override": override,
            "abort": abort,
            "reward": reward,
            "coverage": coverage,
            "route_progress": route_progress,
            "energy_wh_step": energy,
            "rpe_pos_m": rpe_pos,
            "rpe_yaw_rad": rpe_yaw,
        }
        self.step_rows.append(row)

        self.prev_action = np.asarray(action, dtype=np.float32).reshape(1)
        self.prev_policy_speed = policy_speed
        self.prev_governed_speed = command_speed
        self.prev_route_progress = route_progress
        self.prev_coverage = coverage
        self.prev_potential = phi_state
        self.prev_true_pos = self.true_pos.copy()
        self.prev_slam_pos = self.slam_pos.copy()
        self.prev_true_yaw = self.true_yaw
        self.prev_slam_yaw = self.slam_yaw

        self._sync_drone_prim()
        if terminated or truncated:
            self._finish_episode(success=success, aborted=bool(abort))

        info = {
            "source_domain": "e1",
            "success": success,
            "aborted": bool(abort),
            "fallback_reason": reason,
            "vslam_risk_z": z_t,
            "coverage": coverage,
            "route_progress": route_progress,
            "governor_gate": gate,
            "governor_override": override,
        }
        return self._get_obs(), reward, terminated, truncated, info

    def _get_obs(self) -> np.ndarray:
        d_t, phi_t, route_progress = self._route_errors()
        # Use latest risk if available; before first step, compute benign defaults.
        feature_norm = float(getattr(self, "texture_level", 0.72))
        inlier_ratio = float(getattr(self, "illumination_level", 0.80))
        sigma_t = float(np.clip(np.linalg.norm(self.slam_pos - self.true_pos) / 0.5, 0.0, 1.0))
        xi_t = float(np.clip(abs(self._wrap_angle(self.slam_yaw - self.true_yaw)) / max(self.coeffs.phi_abort, 1e-6), 0.0, 1.0))
        ell_t = 1.0 if self.slam_quality <= 0.05 else 0.0
        z_t = self._vslam_risk_score(feature_norm, inlier_ratio, sigma_t, xi_t, ell_t)
        target = self.route[min(self.target_idx, len(self.route) - 1)]
        target_rel = target - self.slam_pos
        rays = self._ray_features()
        obs = np.concatenate(
            [
                np.asarray([feature_norm, inlier_ratio, sigma_t, xi_t, ell_t], dtype=np.float32),
                np.asarray(
                    [
                        self.slam_pos[0],
                        self.slam_pos[1],
                        self.slam_pos[2],
                        math.sin(self.slam_yaw),
                        math.cos(self.slam_yaw),
                        float(np.linalg.norm(self.true_vel)),
                        self.yaw_rate,
                    ],
                    dtype=np.float32,
                ),
                np.asarray([0.0, 0.0, 0.0, 0.0, 0.0, self.yaw_rate], dtype=np.float32),
                np.asarray([self.texture_level, self.illumination_level, self.wind_mps / 2.5], dtype=np.float32),
                np.asarray([d_t / max(self.coeffs.d_limit, 1e-6), phi_t / max(self.coeffs.phi_limit, 1e-6), route_progress], dtype=np.float32),
                target_rel.astype(np.float32) / max(self.world_size, 1.0),
                self.prev_action.astype(np.float32),
                rays.astype(np.float32),
                self.mission_vector.astype(np.float32),
                np.asarray([self.mission_lambda], dtype=np.float32),
            ]
        )
        if obs.shape[0] != self.obs_dim:
            fixed = np.zeros((self.obs_dim,), dtype=np.float32)
            fixed[: min(self.obs_dim, obs.shape[0])] = obs[: min(self.obs_dim, obs.shape[0])]
            return fixed
        return obs.astype(np.float32)

    def _finish_episode(self, success: bool, aborted: bool) -> None:
        steps = max(1, self.step_count)
        row = {
            "run_id": self.run_id,
            "episode": self.episode_id,
            "success": int(success),
            "aborted": int(aborted),
            "steps": steps,
            "waypoints_reached": int(self.target_idx),
            "P_s": float(success),
            "coverage_C": float(self.prev_coverage),
            "E_p_rpe_m": float(np.mean(self.rpe_pos_values)) if self.rpe_pos_values else 0.0,
            "E_psi_rpe_rad": float(np.mean(self.rpe_yaw_values)) if self.rpe_yaw_values else 0.0,
            "E_a_ate_m": float(np.mean(self.ate_values)) if self.ate_values else 0.0,
            "energy_Wh": float(np.sum(self.energy_values)) if self.energy_values else 0.0,
            "override_rate_O": float(self.override_count / steps),
            "abort_rate_A": float(self.abort_count / steps),
            "drift_return_D": float(self.drift_return),
            "mean_vslam_risk_z": float(np.mean(self.risk_values)) if self.risk_values else 0.0,
            "max_vslam_risk_z": float(np.max(self.risk_values)) if self.risk_values else 0.0,
            "mean_speed_mps": float(np.mean(self.speed_values)) if self.speed_values else 0.0,
            "reward_sum": float(self.episode_reward),
            "mission_text": self.mission_text,
            "mission_lambda": float(self.mission_lambda),
        }
        with self.step_csv.open("a", newline="") as f:
            writer = csv.DictWriter(f, fieldnames=self._step_metric_fields())
            writer.writerows(self.step_rows)
        with self.episode_csv.open("a", newline="") as f:
            writer = csv.DictWriter(f, fieldnames=self._episode_metric_fields())
            writer.writerow(row)

        self.summary["episodes"] += 1
        self.summary["successes"] += int(success)
        self.summary["aborts"] += int(aborted)
        self.summary["drift_returns"].append(float(self.drift_return))
        summary_out = dict(self.summary)
        drifts = np.asarray(summary_out.pop("drift_returns"), dtype=np.float32)
        summary_out["success_rate"] = float(self.summary["successes"] / max(1, self.summary["episodes"]))
        summary_out["abort_rate_episode"] = float(self.summary["aborts"] / max(1, self.summary["episodes"]))
        if drifts.size:
            q = float(np.quantile(drifts, self.coeffs.cvar_alpha))
            tail = drifts[drifts >= q]
            summary_out["CVaR_drift"] = float(np.mean(tail)) if tail.size else q
            summary_out["mean_drift_return"] = float(np.mean(drifts))
        summary_out["coefficients"] = asdict(self.coeffs)
        summary_out["route_points"] = int(len(self.route))
        summary_out["source_domain"] = "e1"
        self.summary_json.write_text(json.dumps(summary_out, indent=2), encoding="utf-8")
        self.episode_id += 1

    def close(self) -> None:
        pass


# ---------------------------------------------------------------------------
# Training/evaluation utilities
# ---------------------------------------------------------------------------


def parse_args() -> argparse.Namespace:
    p = argparse.ArgumentParser(description="Source-domain e1 UAV LLM speed-governance training/evaluation.")
    p.add_argument("--mode", choices=["train", "eval", "demo"], default="demo")
    p.add_argument("--headless", action="store_true")
    p.add_argument("--no-isaac", action="store_true", help="Do not start Isaac Sim; run algorithmic Gym environment only.")
    p.add_argument("--renderer", default="RayTracedLighting")
    p.add_argument("--device", choices=["cpu", "cuda"], default="cpu")
    p.add_argument("--seed", type=int, default=7)
    p.add_argument("--output-root", type=str, default="~/uav_results_e1")
    p.add_argument("--model-path", type=str, default="")
    p.add_argument("--total-timesteps", type=int, default=200000)
    p.add_argument("--eval-episodes", type=int, default=20)
    p.add_argument("--demo-steps", type=int, default=500)
    p.add_argument("--demo-action", type=float, default=0.0)
    p.add_argument("--max-episode-steps", type=int, default=6000)
    p.add_argument("--route-repeat-count", type=int, default=1)
    p.add_argument("--world-size", type=float, default=64.0)
    p.add_argument("--inspection-altitude", type=float, default=12.0)
    p.add_argument("--inspection-reach-radius", type=float, default=1.25)
    p.add_argument("--num-rays", type=int, default=36)
    p.add_argument("--disable-domain-randomization", action="store_true")
    p.add_argument("--enable-route-randomization", action="store_true")
    p.add_argument("--disable-collision-termination", action="store_true")

    # Mission settings.
    p.add_argument("--mission-text", type=str, default="E:low-texture G:coverage S:feature-slow O:slow-smooth")
    p.add_argument("--mission-encoder", choices=["structured", "llama_hf"], default="structured")
    p.add_argument("--mission-dim", type=int, default=16)
    p.add_argument("--hf-llama-model", type=str, default="meta-llama/Meta-Llama-3-8B-Instruct")
    p.add_argument("--hf-token", type=str, default=os.environ.get("HF_TOKEN", ""))
    p.add_argument("--hf-local-files-only", action="store_true")
    p.add_argument("--hf-load-in-4bit", action="store_true")
    p.add_argument("--hf-device-map", type=str, default="auto")

    # Paper coefficients are exposed but default to the manuscript table.
    p.add_argument("--speed-min", type=float, default=0.30)
    p.add_argument("--speed-max", type=float, default=2.00)
    p.add_argument("--governor-alpha", type=float, default=0.60)
    p.add_argument("--governor-beta", type=float, default=0.40)
    p.add_argument("--governor-rate-limit", type=float, default=0.20)
    p.add_argument("--vslam-risk-limit", type=float, default=0.70)
    p.add_argument("--abort-risk-limit", type=float, default=0.90)
    p.add_argument("--corridor-limit", type=float, default=0.50)
    p.add_argument("--abort-corridor-limit", type=float, default=0.80)
    p.add_argument("--yaw-limit-deg", type=float, default=20.05)
    p.add_argument("--abort-yaw-limit-deg", type=float, default=34.38)
    p.add_argument("--fallback-speed", type=float, default=0.0)
    return p.parse_args()


def coeffs_from_args(args: argparse.Namespace) -> PaperCoefficients:
    c = PaperCoefficients()
    c.speed_min = float(args.speed_min)
    c.speed_max = float(args.speed_max)
    c.alpha = float(args.governor_alpha)
    c.beta = float(args.governor_beta)
    c.rate_limit = float(args.governor_rate_limit)
    c.z_limit = float(args.vslam_risk_limit)
    c.z_abort = float(args.abort_risk_limit)
    c.d_limit = float(args.corridor_limit)
    c.d_abort = float(args.abort_corridor_limit)
    c.phi_limit = math.radians(float(args.yaw_limit_deg))
    c.phi_abort = math.radians(float(args.abort_yaw_limit_deg))
    c.fallback_speed = float(args.fallback_speed)
    return c


def maybe_start_isaac(args: argparse.Namespace):
    if args.no_isaac:
        return None, None
    try:
        from isaacsim import SimulationApp  # type: ignore

        app = SimulationApp({"headless": bool(args.headless), "renderer": str(args.renderer)})
        import omni.usd  # type: ignore

        context = omni.usd.get_context()
        context.new_stage()
        stage = context.get_stage()
        return app, stage
    except Exception as exc:
        print(f"[ISAAC] Could not start Isaac Sim. Falling back to --no-isaac behavior. Reason: {exc}")
        return None, None


def make_env(args: argparse.Namespace, stage: Any = None) -> SourceE1UAVEnv:
    return SourceE1UAVEnv(
        render_stage=stage is not None,
        stage=stage,
        seed=int(args.seed),
        output_root=str(args.output_root),
        max_episode_steps=int(args.max_episode_steps),
        mission_text=str(args.mission_text),
        mission_encoder=str(args.mission_encoder),
        mission_dim=int(args.mission_dim),
        hf_llama_model=str(args.hf_llama_model),
        hf_token=str(args.hf_token or ""),
        hf_local_files_only=bool(args.hf_local_files_only),
        hf_load_in_4bit=bool(args.hf_load_in_4bit),
        hf_device_map=str(args.hf_device_map),
        route_repeat_count=int(args.route_repeat_count),
        world_size=float(args.world_size),
        inspection_altitude=float(args.inspection_altitude),
        inspection_reach_radius=float(args.inspection_reach_radius),
        num_rays=int(args.num_rays),
        domain_randomization=not bool(args.disable_domain_randomization),
        route_randomization=bool(args.enable_route_randomization),
        collision_termination=not bool(args.disable_collision_termination),
        coeffs=coeffs_from_args(args),
    )


def train(args: argparse.Namespace, stage: Any = None) -> None:
    try:
        from stable_baselines3 import PPO
        from stable_baselines3.common.monitor import Monitor
    except Exception as exc:
        raise RuntimeError("stable-baselines3 is required for --mode train. Install stable-baselines3 in the Isaac/Python env.") from exc

    env = Monitor(make_env(args, stage=stage))
    model_dir = Path(args.output_root).expanduser() / "models"
    model_dir.mkdir(parents=True, exist_ok=True)
    model_path = Path(args.model_path).expanduser() if args.model_path else model_dir / "source_e1_ppo.zip"

    model = PPO(
        "MlpPolicy",
        env,
        learning_rate=3e-4,
        gamma=0.99,
        gae_lambda=0.95,
        clip_range=0.20,
        n_steps=1024,
        batch_size=256,
        ent_coef=0.01,
        vf_coef=0.5,
        verbose=1,
        seed=int(args.seed),
        device=str(args.device),
    )
    model.learn(total_timesteps=int(args.total_timesteps))
    model.save(str(model_path))
    print(f"[TRAIN] Saved source-domain e1 PPO model to {model_path}")
    env.close()


def evaluate(args: argparse.Namespace, stage: Any = None) -> None:
    try:
        from stable_baselines3 import PPO
    except Exception as exc:
        raise RuntimeError("stable-baselines3 is required for --mode eval.") from exc

    env = make_env(args, stage=stage)
    model_path = Path(args.model_path).expanduser() if args.model_path else Path(args.output_root).expanduser() / "models" / "source_e1_ppo.zip"
    model = PPO.load(str(model_path), device=str(args.device))
    successes = 0
    for ep in range(int(args.eval_episodes)):
        obs, _info = env.reset(seed=int(args.seed) + ep)
        done = False
        truncated = False
        while not (done or truncated):
            action, _state = model.predict(obs, deterministic=True)
            obs, _reward, done, truncated, info = env.step(action)
        successes += int(info.get("success", False))
        print(f"[EVAL] episode={ep} success={info.get('success')} coverage={info.get('coverage'):.3f} abort={info.get('aborted')}")
    print(f"[EVAL] source-domain e1 success_rate={successes / max(1, int(args.eval_episodes)):.3f}")
    env.close()


def demo(args: argparse.Namespace, stage: Any = None, sim_app: Any = None) -> None:
    env = make_env(args, stage=stage)
    obs, _info = env.reset(seed=int(args.seed))
    action = np.asarray([float(np.clip(args.demo_action, -1.0, 1.0))], dtype=np.float32)
    for k in range(int(args.demo_steps)):
        obs, reward, done, truncated, info = env.step(action)
        if k % 50 == 0:
            print(
                f"[DEMO] step={k} reward={reward:.3f} z={info['vslam_risk_z']:.3f} "
                f"coverage={info['coverage']:.3f} gate={info['governor_gate']} reason={info['fallback_reason']}"
            )
        if sim_app is not None:
            try:
                sim_app.update()
            except Exception:
                pass
        if done or truncated:
            print(f"[DEMO] finished done={done} truncated={truncated} info={info}")
            break
    env.close()


def main() -> None:
    args = parse_args()
    sim_app, stage = maybe_start_isaac(args)
    try:
        if args.mode == "train":
            train(args, stage=stage)
        elif args.mode == "eval":
            evaluate(args, stage=stage)
        else:
            demo(args, stage=stage, sim_app=sim_app)
    finally:
        if sim_app is not None:
            try:
                sim_app.close()
            except Exception:
                pass


if __name__ == "__main__":
    main()
