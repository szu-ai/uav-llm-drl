#!/usr/bin/env python3
"""Procedural source-domain e1 power-plant scene for UAV inspection.

This module intentionally contains only the visual/source-domain scene and the
16-point inspection route used by the source-domain paper experiments.  The
training/control logic lives in ``uav_llm.py`` and imports this module.

The functions are safe to import without Isaac Sim.  USD/Isaac imports are done
inside functions so the Gym environment can still be unit-tested in pure Python.
"""

from __future__ import annotations

from dataclasses import dataclass
import math
from typing import Dict, List, Tuple

import numpy as np


@dataclass(frozen=True)
class BoxObstacle:
    """Axis-aligned obstacle used by the lightweight Gym dynamics.

    center and size are in meters in the e1 world frame.
    """

    name: str
    center: Tuple[float, float, float]
    size: Tuple[float, float, float]


@dataclass(frozen=True)
class CylinderObstacle:
    """Cylindrical obstacle approximation for chimneys/tanks."""

    name: str
    center: Tuple[float, float, float]
    radius: float
    height: float


@dataclass
class PowerPlantConfig:
    """Scene and route configuration for source domain e1 only."""

    world_size: float = 64.0
    inspection_altitude: float = 12.0
    route_repeat_count: int = 1
    route_margin_x: float = 21.0
    route_margin_y: float = 18.0
    lane_count: int = 4
    points_per_lane: int = 4
    add_smoke: bool = True
    realistic_materials: bool = True


# ---------------------------------------------------------------------------
# Source-domain route
# ---------------------------------------------------------------------------


def source_e1_inspection_points(config: PowerPlantConfig | None = None) -> np.ndarray:
    """Return the paper-aligned 16 unique e1 source-domain inspection points.

    The points follow a boustrophedon sweep around the procedural power plant.
    Only e1/source-domain route generation is provided here.  Target/e2 route
    logic is intentionally removed and should be implemented in a separate file.
    """

    cfg = config or PowerPlantConfig()
    z = float(cfg.inspection_altitude)
    xs = np.linspace(-cfg.route_margin_x, cfg.route_margin_x, cfg.points_per_lane)
    ys = np.linspace(-cfg.route_margin_y, cfg.route_margin_y, cfg.lane_count)

    pts: List[List[float]] = []
    for lane_idx, y in enumerate(ys):
        row_xs = xs if lane_idx % 2 == 0 else xs[::-1]
        for x in row_xs:
            pts.append([float(x), float(y), z])

    out = np.asarray(pts, dtype=np.float32)
    if out.shape != (16, 3):
        raise RuntimeError(f"source_e1_inspection_points must return 16x3, got {out.shape}")
    return out


def source_e1_route(config: PowerPlantConfig | None = None) -> np.ndarray:
    """Return the drone route targets for source e1.

    ``route_repeat_count`` can repeat the same 16-point source route for longer
    training episodes, but no additional e2/target route is included.
    """

    cfg = config or PowerPlantConfig()
    base = source_e1_inspection_points(cfg)
    repeat = max(1, int(cfg.route_repeat_count))
    if repeat == 1:
        return base.copy()
    route = [base]
    for k in range(1, repeat):
        # Alternate direction to avoid a teleport-like jump at repeat boundary.
        route.append(base[::-1] if k % 2 == 1 else base)
    return np.concatenate(route, axis=0).astype(np.float32)


# ---------------------------------------------------------------------------
# Obstacles and proxy visual features
# ---------------------------------------------------------------------------


def source_e1_box_obstacles() -> List[BoxObstacle]:
    """Analytic collision/avoidance boxes for e1."""

    return [
        BoxObstacle("main_turbine_hall", (0.0, 0.0, 4.0), (18.0, 10.0, 8.0)),
        BoxObstacle("boiler_block_west", (-16.0, 2.0, 5.5), (9.0, 13.0, 11.0)),
        BoxObstacle("boiler_block_east", (16.0, -3.0, 5.5), (9.0, 13.0, 11.0)),
        BoxObstacle("control_building", (0.0, -18.0, 3.0), (16.0, 6.0, 6.0)),
        BoxObstacle("cooling_unit_north", (-10.0, 18.0, 3.0), (8.0, 6.0, 6.0)),
        BoxObstacle("cooling_unit_south", (10.0, 18.0, 3.0), (8.0, 6.0, 6.0)),
        BoxObstacle("pipe_bridge", (0.0, 10.0, 7.0), (30.0, 2.0, 2.5)),
    ]


def source_e1_cylinder_obstacles() -> List[CylinderObstacle]:
    """Cylindrical chimneys/tanks for e1."""

    return [
        CylinderObstacle("chimney_1", (-23.0, 11.0, 10.0), 1.4, 20.0),
        CylinderObstacle("chimney_2", (-19.0, 15.0, 11.0), 1.2, 22.0),
        CylinderObstacle("chimney_3", (22.0, -10.0, 10.0), 1.4, 20.0),
        CylinderObstacle("chimney_4", (18.0, -15.0, 11.0), 1.2, 22.0),
        CylinderObstacle("storage_tank_1", (-24.0, -16.0, 3.0), 3.2, 6.0),
        CylinderObstacle("storage_tank_2", (24.0, 15.0, 3.0), 3.2, 6.0),
    ]


def source_e1_feature_points(config: PowerPlantConfig | None = None, seed: int = 2026) -> np.ndarray:
    """Generate proxy VSLAM feature points around route, edges, pipes, and chimneys."""

    cfg = config or PowerPlantConfig()
    rng = np.random.default_rng(seed)
    clusters: List[np.ndarray] = []

    def add_cluster(center: Tuple[float, float, float] | np.ndarray, scale: Tuple[float, float, float], n: int) -> None:
        c = np.asarray(center, dtype=np.float32).reshape(1, 3)
        s = np.asarray(scale, dtype=np.float32).reshape(1, 3)
        clusters.append(c + rng.normal(0.0, 1.0, size=(n, 3)).astype(np.float32) * s)

    for p in source_e1_inspection_points(cfg):
        add_cluster(p, (0.65, 0.65, 0.45), 80)

    for box in source_e1_box_obstacles():
        cx, cy, cz = box.center
        sx, sy, sz = box.size
        # Corners and roof edges have strong visual texture.
        for dx in (-0.5, 0.5):
            for dy in (-0.5, 0.5):
                add_cluster((cx + dx * sx, cy + dy * sy, cz + 0.45 * sz), (0.45, 0.45, 0.35), 28)

    for cyl in source_e1_cylinder_obstacles():
        cx, cy, cz = cyl.center
        for k in range(8):
            theta = 2.0 * math.pi * k / 8.0
            add_cluster(
                (cx + cyl.radius * math.cos(theta), cy + cyl.radius * math.sin(theta), cz + 0.25 * cyl.height),
                (0.20, 0.20, 0.80),
                16,
            )

    pts = np.concatenate(clusters, axis=0).astype(np.float32)
    return pts


# ---------------------------------------------------------------------------
# USD scene construction
# ---------------------------------------------------------------------------


def _require_pxr():
    from pxr import Gf, Sdf, UsdGeom, UsdLux, UsdShade  # type: ignore

    return Gf, Sdf, UsdGeom, UsdLux, UsdShade


def _define_material(stage, name: str, color: Tuple[float, float, float], roughness: float = 0.75) -> str:
    """Create a simple USD preview material and return its path."""

    _Gf, Sdf, _UsdGeom, _UsdLux, UsdShade = _require_pxr()
    path = f"/World/Materials/{name}"
    mat = UsdShade.Material.Define(stage, path)
    shader = UsdShade.Shader.Define(stage, f"{path}/PreviewSurface")
    shader.CreateIdAttr("UsdPreviewSurface")
    shader.CreateInput("diffuseColor", Sdf.ValueTypeNames.Color3f).Set(color)
    shader.CreateInput("roughness", Sdf.ValueTypeNames.Float).Set(float(roughness))
    shader.CreateInput("metallic", Sdf.ValueTypeNames.Float).Set(0.05)
    mat.CreateSurfaceOutput().ConnectToSource(shader.ConnectableAPI(), "surface")
    return path


def _bind_material(stage, prim_path: str, mat_path: str) -> None:
    _Gf, _Sdf, _UsdGeom, _UsdLux, UsdShade = _require_pxr()
    prim = stage.GetPrimAtPath(prim_path)
    mat = UsdShade.Material.Get(stage, mat_path)
    if prim and prim.IsValid() and mat:
        UsdShade.MaterialBindingAPI(prim).Bind(mat)


def _cube(stage, path: str, center: Tuple[float, float, float], size: Tuple[float, float, float], mat_path: str) -> None:
    Gf, _Sdf, UsdGeom, _UsdLux, _UsdShade = _require_pxr()
    prim = UsdGeom.Cube.Define(stage, path)
    xform = UsdGeom.Xformable(prim.GetPrim())
    xform.AddTranslateOp().Set(Gf.Vec3d(*map(float, center)))
    xform.AddScaleOp().Set(Gf.Vec3f(float(size[0]), float(size[1]), float(size[2])))
    _bind_material(stage, path, mat_path)


def _cylinder(stage, path: str, center: Tuple[float, float, float], radius: float, height: float, mat_path: str) -> None:
    Gf, _Sdf, UsdGeom, _UsdLux, _UsdShade = _require_pxr()
    prim = UsdGeom.Cylinder.Define(stage, path)
    prim.CreateRadiusAttr(float(radius))
    prim.CreateHeightAttr(float(height))
    xform = UsdGeom.Xformable(prim.GetPrim())
    xform.AddTranslateOp().Set(Gf.Vec3d(float(center[0]), float(center[1]), float(center[2])))
    _bind_material(stage, path, mat_path)


def _sphere(stage, path: str, center: Tuple[float, float, float], radius: float, mat_path: str) -> None:
    Gf, _Sdf, UsdGeom, _UsdLux, _UsdShade = _require_pxr()
    prim = UsdGeom.Sphere.Define(stage, path)
    prim.CreateRadiusAttr(float(radius))
    xform = UsdGeom.Xformable(prim.GetPrim())
    xform.AddTranslateOp().Set(Gf.Vec3d(*map(float, center)))
    _bind_material(stage, path, mat_path)


def build_power_plant_source_scene(stage, config: PowerPlantConfig | None = None) -> Dict[str, object]:
    """Build the e1 source-domain power-plant USD scene on an existing stage.

    Returns a dictionary with collision primitives and route data.  If Isaac USD
    modules are unavailable this function raises ImportError, while the route and
    obstacle helpers above still work without Isaac.
    """

    cfg = config or PowerPlantConfig()
    Gf, _Sdf, UsdGeom, UsdLux, _UsdShade = _require_pxr()

    UsdGeom.SetStageUpAxis(stage, UsdGeom.Tokens.z)
    UsdGeom.SetStageMetersPerUnit(stage, 1.0)

    # Root scopes.
    UsdGeom.Xform.Define(stage, "/World")
    UsdGeom.Xform.Define(stage, "/World/Materials")
    UsdGeom.Xform.Define(stage, "/World/Plant")
    UsdGeom.Xform.Define(stage, "/World/Route")
    UsdGeom.Xform.Define(stage, "/World/Smoke")

    materials = {
        "ground": _define_material(stage, "mat_ground_concrete", (0.45, 0.45, 0.42), 0.85),
        "wall_blue": _define_material(stage, "mat_weathered_blue_steel", (0.18, 0.28, 0.42), 0.70),
        "wall_red": _define_material(stage, "mat_rust_red_steel", (0.50, 0.18, 0.12), 0.78),
        "wall_gray": _define_material(stage, "mat_industrial_gray", (0.36, 0.38, 0.38), 0.80),
        "pipe": _define_material(stage, "mat_pipe_yellow", (0.82, 0.58, 0.12), 0.65),
        "chimney": _define_material(stage, "mat_chimney_concrete", (0.62, 0.62, 0.58), 0.82),
        "tank": _define_material(stage, "mat_tank_green", (0.23, 0.38, 0.28), 0.78),
        "route": _define_material(stage, "mat_route_marker", (0.10, 0.75, 0.95), 0.50),
        "smoke": _define_material(stage, "mat_smoke_gray", (0.55, 0.55, 0.55), 0.95),
        "drone": _define_material(stage, "mat_drone_dark", (0.05, 0.05, 0.06), 0.45),
    }

    # Ground plane as a very thin cube to render reliably in RTX.
    _cube(stage, "/World/Plant/ground", (0.0, 0.0, -0.04), (cfg.world_size, cfg.world_size, 0.04), materials["ground"])

    # Buildings and pipe bridge.
    for box in source_e1_box_obstacles():
        mat = materials["wall_blue"] if "boiler" in box.name else materials["wall_gray"]
        if "control" in box.name:
            mat = materials["wall_red"]
        if "pipe" in box.name:
            mat = materials["pipe"]
        _cube(stage, f"/World/Plant/{box.name}", box.center, box.size, mat)

    # Chimneys, tanks, smoke.
    for cyl in source_e1_cylinder_obstacles():
        mat = materials["chimney"] if "chimney" in cyl.name else materials["tank"]
        _cylinder(stage, f"/World/Plant/{cyl.name}", cyl.center, cyl.radius, cyl.height, mat)
        if cfg.add_smoke and "chimney" in cyl.name:
            x, y, z = cyl.center
            top_z = z + 0.5 * cyl.height
            for j in range(5):
                _sphere(
                    stage,
                    f"/World/Smoke/{cyl.name}_smoke_{j}",
                    (x + 0.25 * j, y + 0.15 * math.sin(j), top_z + 1.0 + 1.5 * j),
                    0.75 + 0.20 * j,
                    materials["smoke"],
                )

    # Route markers.
    pts = source_e1_inspection_points(cfg)
    for i, p in enumerate(pts):
        _sphere(stage, f"/World/Route/wp_{i:02d}", (float(p[0]), float(p[1]), float(p[2])), 0.28, materials["route"])

    # Simple drone body placeholder.  The control script moves this prim.
    _cube(stage, "/World/Drone/body", (float(pts[0, 0]), float(pts[0, 1]), float(pts[0, 2])), (0.45, 0.30, 0.12), materials["drone"])

    # Daylight for realistic source domain.
    sun = UsdLux.DistantLight.Define(stage, "/World/Lights/MiddaySun")
    sun.CreateIntensityAttr(14500.0)
    sun.CreateAngleAttr(0.35)
    UsdGeom.Xformable(sun.GetPrim()).AddRotateXYZOp().Set(Gf.Vec3f(-45.0, 0.0, 35.0))

    dome = UsdLux.DomeLight.Define(stage, "/World/Lights/SkyDome")
    dome.CreateIntensityAttr(2400.0)

    return {
        "route": source_e1_route(cfg),
        "inspection_points": pts,
        "box_obstacles": source_e1_box_obstacles(),
        "cylinder_obstacles": source_e1_cylinder_obstacles(),
        "feature_points": source_e1_feature_points(cfg),
        "materials": materials,
        "drone_path": "/World/Drone/body",
    }


__all__ = [
    "BoxObstacle",
    "CylinderObstacle",
    "PowerPlantConfig",
    "source_e1_inspection_points",
    "source_e1_route",
    "source_e1_box_obstacles",
    "source_e1_cylinder_obstacles",
    "source_e1_feature_points",
    "build_power_plant_source_scene",
]
